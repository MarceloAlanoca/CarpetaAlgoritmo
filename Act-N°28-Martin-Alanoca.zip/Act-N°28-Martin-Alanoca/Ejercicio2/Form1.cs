﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double temp = double.Parse(textBox1.Text);

         
            if (radioButton1.Checked)
            {
                double CF = (temp * 1.8) + 32;
                label1.Text = $"La conversion de: {temp}°C a FAHRENHEIT es de: {CF}°F";
            }
            if (radioButton2.Checked) 
            {
                double FC = (temp - 32) / 1.8;
                label1.Text = $"La conversion de: {temp}°F a CELSIUS es de: {FC}°C";
            }
            label1.Visible = true;

        }
    }
}
