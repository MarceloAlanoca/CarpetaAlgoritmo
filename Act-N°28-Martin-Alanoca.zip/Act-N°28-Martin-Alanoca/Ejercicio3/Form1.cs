﻿using Microsoft.Win32;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var valor = textBox1.Text;
            ListBox listBox1 = new ListBox();

            this.listBox1.Items.Add(valor);
            listBox1.BeginUpdate();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var valor = textBox1.Text;
            int lista = listBox1.Items.IndexOf(valor);

            if (lista != -1)
            {
                listBox1.Items.RemoveAt(lista);
            }
            else
            {
                Text = "no se a encontrado";
            }
        }
    }
}
