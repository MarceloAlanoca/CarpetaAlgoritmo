﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            label1.Visible = false;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double valor1 = double.Parse(textBox1.Text);
            double valor2 = double.Parse(textBox2.Text);
            double valor3 = double.Parse(textBox3.Text);

            double resultado = valor1 + valor2 + valor3;
            double promedio = resultado / 3;

            label1.Visible = true;

            if (promedio >= 6) 
            {
                label1.Text = "Felizidades pasates con: " + promedio;
            }
            else if (promedio < 6)
            {
                label1.Text = "Reprobaste sacaste " + promedio;
            }
        }
    }
}
