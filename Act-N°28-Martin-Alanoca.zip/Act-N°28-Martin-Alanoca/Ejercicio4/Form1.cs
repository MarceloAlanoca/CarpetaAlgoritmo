﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement.TrackBar;

namespace Ejercicio4
{
    public partial class Form1 : Form
    {
        int Ticks = 0;
        public Form1()
        {
            InitializeComponent();

        }

        private void Button1_Click(object sender, EventArgs e)
        {
            Ticks++;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            MessageBox.Show($"haz dado {Ticks} clicks");
            button1.Enabled = false;
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            Timer MyTimer = new Timer();
            MyTimer.Interval = (10 * 1000); 
            MyTimer.Tick += new EventHandler(timer1_Tick);
            MyTimer.Start();
        }
    }
}
