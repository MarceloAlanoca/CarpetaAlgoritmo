namespace Ejercicio1
{
    /*
        1. Disponer tres objetos de la clase CheckBox con nombres de navegadores web.
            Cuando se presione un botón mostrar en el título del Form los programas
            seleccionados.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Text = "";
            if(checkBox1.Checked == true)
            {
                Text = Text + "Google Chrome ";
            }
            if(checkBox2.Checked == true)
            {
                Text = Text + "Mozilla Firefox ";
            }
            if (checkBox3.Checked == true)
            {
                Text = Text + "Microsoft Edge ";
            }
        }
    }
}
