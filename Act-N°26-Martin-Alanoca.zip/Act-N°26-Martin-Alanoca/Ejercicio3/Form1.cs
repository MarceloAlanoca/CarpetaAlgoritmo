﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Ejercicio3
{
    /*
        3. Solicitar el ingreso del nombre de una persona y seleccionar de un control
            ComboBox un país. Al presionar un botón mostrar en la barra del título del
            Form el nombre ingresado y el país seleccionado.
     */
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            var nombre = textBox1.Text;
            var pais = comboBox1.SelectedItem?.ToString() ?? "No seleccionado";

            Text = $"Nombre: {nombre}, País: {pais}";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
            comboBox1.Items.Add("Argentina");
            comboBox1.Items.Add("Bolivia");
            comboBox1.Items.Add("Paraguay");
            comboBox1.Items.Add("Peru");
            comboBox1.Items.Add("Chile");
            comboBox1.Items.Add("Brazil");
            comboBox1.Items.Add("Colombia");
            comboBox1.Items.Add("Italia");
            comboBox1.Items.Add("Francia");
            comboBox1.Items.Add("Uruguay");
            comboBox1.Items.Add("Armenia");
            comboBox1.Items.Add("Russia");
            comboBox1.SelectedIndex = 0;
        }
    }
}
